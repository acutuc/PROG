package ej1;

/**
 *
 * @author acutuc
 */
public enum Palos {
    PICAS, 
    ROMBOS, 
    TREBOLES, 
    CORAZONES;
    
}
